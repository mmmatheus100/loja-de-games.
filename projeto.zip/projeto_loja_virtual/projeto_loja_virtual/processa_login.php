<?php
session_start();

// Conexão com o banco de dados
$host = 'localhost';
$dbname = 'loja';
$user = 'root';
$pass = '';
$conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);

// Verificar se o e-mail e a senha foram enviados
if (isset($_POST['email']) && isset($_POST['senha'])) {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    // Verificar se o usuário existe
    $sql = "SELECT * FROM usuarios WHERE email = ? AND senha = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$email, $senha]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($usuario) {
        // Login bem-sucedido
        $_SESSION['usuario_id'] = $usuario['id'];
        $_SESSION['usuario_email'] = $usuario['email'];

        // Redirecionar para a página de início
        header("Location: index.html");
        exit(); // Não esqueça do exit() para garantir que o script pare aqui
    } else {
        echo "E-mail ou senha incorretos.";
    }
}
?>
