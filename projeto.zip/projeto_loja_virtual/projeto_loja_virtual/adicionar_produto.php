<?php
// include 'conexao.php'; // Inclui a conexão com o banco de dados

// Array de produtos a serem adicionados ao banco de dados
/*
$produtos = [
    [
        'nome' => 'FIFA 24',
        'descricao' => 'EA SPORTS FC™ 24',
        'preco' => 59.90,
        'imagem' => 'assets/fifa.jfif'
    ],
    [
        'nome' => 'Mortal Kombat',
        'descricao' => 'MORTAL KOMBAT',
        'preco' => 59.90,
        'imagem' => 'assets/mortalkombat.jfif'
    ],
    [
        'nome' => 'Mad Max',
        'descricao' => 'MAD MAX',
        'preco' => 59.90,
        'imagem' => 'assets/madmax.jfif'
    ],
    [
        'nome' => 'Grand Theft Auto',
        'descricao' => 'GRAND THEFT AUTO',
        'preco' => 59.90,
        'imagem' => 'assets/gta.jfif'
    ],
    [
        'nome' => 'Ghost Recon',
        'descricao' => 'GHOST RECON',
        'preco' => 59.90,
        'imagem' => 'assets/ghostrecon.jfif'
    ],
    [
        'nome' => 'Forza Horizon 2',
        'descricao' => 'FORZA HORIZON 2',
        'preco' => 59.90,
        'imagem' => 'assets/FORZA.webp'
    ],
    [
        'nome' => 'Tomb Raider',
        'descricao' => 'TOMB RAIDER',
        'preco' => 59.90,
        'imagem' => 'assets/tombraider.jfif'
    ],
    [
        'nome' => 'Need for Speed',
        'descricao' => 'NEED FOR SPEED',
        'preco' => 59.90,
        'imagem' => 'assets/NEED FOR SPEED.jpg'
    ],
    [
        'nome' => 'Call of Duty',
        'descricao' => 'CALL OF DUTY',
        'preco' => 59.90,
        'imagem' => 'assets/CALL OF DUTY.jpg'
    ],
    [
        'nome' => 'Gears of War',
        'descricao' => 'GEARS OF WAR',
        'preco' => 59.90,
        'imagem' => 'assets/GEARS OF WAR.jfif'
    ]
];
*/

// Loop para inserir cada produto no banco de dados
/*
foreach ($produtos as $produto) {
    $sql = "INSERT INTO produtos (nome_produto, descricao, preco, imagem) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssds", $produto['nome'], $produto['descricao'], $produto['preco'], $produto['imagem']);

    if ($stmt->execute()) {
        echo "Produto '{$produto['nome']}' inserido com sucesso!<br>";
    } else {
        echo "Erro ao inserir produto '{$produto['nome']}': " . $stmt->error . "<br>";
    }

    $stmt->close();
}
*/

// Fecha a conexão
// $conn->close();
?>
