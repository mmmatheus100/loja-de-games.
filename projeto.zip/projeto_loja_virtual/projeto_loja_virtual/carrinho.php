<?php
session_start();
include 'conexao.php'; // Conecta ao banco de dados

// Verifica se o usuário está autenticado
if (!isset($_SESSION['usuario_id'])) {
    echo "Você precisa fazer login para ver o carrinho.";
    exit;
}

$usuario_id = $_SESSION['usuario_id']; // ID do usuário logado

// Preparar a consulta SQL usando Prepared Statements para maior segurança
$sql = "SELECT c.id AS id_carrinho, p.id AS id_produto, p.descricao AS nome, c.quantidade, p.preco 
        FROM carrinho c
        JOIN produtos p ON c.id_produto = p.id
        WHERE c.id_usuario = ?"; // Usando ? como placeholder

// Preparar a consulta
if ($stmt = $conn->prepare($sql)) {
    // Vincular o parâmetro (usuário ID)
    $stmt->bind_param("i", $usuario_id); // "i" indica que é um inteiro

    // Executar a consulta
    $stmt->execute();

    // Obter os resultados
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        echo "Carrinho vazio.";
        exit;
    }

    $total = 0;
    echo "<h1>Seu Carrinho</h1>";

    // Iniciar formulário para atualização de quantidades
    echo '<form method="post" action="atualizar_carrinho.php">';

    // Tabela para exibir os produtos no carrinho
    echo '<table class="tabela-carrinho">';
    echo '<tr><th>Produto</th><th>Quantidade</th><th>Preço</th><th>Subtotal</th><th>Ações</th></tr>';

    while ($row = $result->fetch_assoc()) {
        $subtotal = $row['preco'] * $row['quantidade'];
        $total += $subtotal;
        echo "<tr>";
        echo "<td>" . $row['nome'] . "</td>"; // Alterado para 'nome'
        echo '<td><input type="number" name="quantidade[' . $row['id_carrinho'] . ']" value="' . $row['quantidade'] . '" min="1" class="input-quantidade"></td>';
        echo "<td>R$ " . number_format($row['preco'], 2, ',', '.') . "</td>";
        echo "<td>R$ " . number_format($subtotal, 2, ',', '.') . "</td>";
        echo '<td><a href="remover_carrinho.php?id_produto=' . $row['id_produto'] . '" class="link-remover">Remover</a></td>';
        echo "</tr>";
    }

    echo '</table>';
    echo "<h3 class='total'>Total: R$ " . number_format($total, 2, ',', '.') . "</h3>";
    echo '<button type="submit" class="botao-atualizar">Atualizar Carrinho</button>';
    echo '</form>'; // Fechar formulário

    // Fechar o statement
    $stmt->close();
    
} else {
    echo "Erro na consulta SQL: " . $conn->error;
}

// Fechar a conexão
$conn->close();
?>

<a href="pagamento.php" class="link-finalizar">Finalizar compra</a>

<!-- Estilo CSS incorporado diretamente no arquivo -->
<style>
    /* Estilos gerais para a página do carrinho */
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f5f5f5;
    }

    h1 {
        text-align: center;
        margin-top: 20px;
        font-size: 2em;
    }

    .tabela-carrinho {
        width: 80%;
        margin: 20px auto;
        border-collapse: collapse;
        background-color: #fff;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .tabela-carrinho th, .tabela-carrinho td {
        padding: 10px;
        text-align: center;
        border: 1px solid #ddd;
    }

    .tabela-carrinho th {
        background-color: #333;
        color: white;
    }

    .input-quantidade {
        width: 60px;
        padding: 5px;
        text-align: center;
    }

    .link-remover {
        color: #f44336;
        text-decoration: none;
    }

    .link-remover:hover {
        text-decoration: underline;
    }

    .total {
        text-align: right;
        font-size: 1.2em;
        margin-right: 10%;
    }

    .botao-atualizar {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        margin-top: 20px;
        display: block;
        margin-left: auto;
        margin-right: auto;
    }

    .botao-atualizar:hover {
        background-color: #45a049;
    }

    .link-finalizar {
        display: block;
        text-align: center;
        margin-top: 30px;
        color: #2196F3;
        font-size: 1.2em;
        text-decoration: none;
    }

    .link-finalizar:hover {
        text-decoration: underline;
    }
</style>
