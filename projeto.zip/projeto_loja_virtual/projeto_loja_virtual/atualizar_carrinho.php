<?php
session_start();
include 'conexao.php'; // Conecta ao banco de dados

// Verifica se o usuário está autenticado
if (!isset($_SESSION['usuario_id'])) {
    echo "Você precisa fazer login para atualizar o carrinho.";
    exit;
}

$usuario_id = $_SESSION['usuario_id']; // ID do usuário logado

// Verifica se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Processa cada produto no carrinho
    if (isset($_POST['quantidade'])) {
        foreach ($_POST['quantidade'] as $id_carrinho => $quantidade) {
            // Verifica se a quantidade é válida (maior que 0)
            if ($quantidade > 0) {
                // Prepara a consulta SQL para atualizar a quantidade
                $sql = "UPDATE carrinho SET quantidade = ? WHERE id = ? AND id_usuario = ?";
                if ($stmt = $conn->prepare($sql)) {
                    // Vincula os parâmetros (quantidade, id do carrinho e id do usuário)
                    $stmt->bind_param("iii", $quantidade, $id_carrinho, $usuario_id);

                    // Executa a consulta
                    if ($stmt->execute()) {
                        echo "Carrinho atualizado com sucesso!";
                    } else {
                        echo "Erro ao atualizar o carrinho: " . $stmt->error;
                    }

                    // Fecha o statement
                    $stmt->close();
                } else {
                    echo "Erro ao preparar a consulta: " . $conn->error;
                }
            } else {
                echo "Quantidade inválida para o produto de ID: $id_carrinho.";
            }
        }
    }
}

// Redireciona para o carrinho atualizado
header("Location: carrinho.php");
exit();
?>
