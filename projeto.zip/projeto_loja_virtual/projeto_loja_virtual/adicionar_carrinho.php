<?php
session_start();
include 'conexao.php'; // Inclui o arquivo de conexão com mysqli

// Verifica se o usuário está autenticado
if (!isset($_SESSION['usuario_id'])) {
    echo "Você precisa fazer login para adicionar produtos ao carrinho.";
    exit;
}

$usuario_id = $_SESSION['usuario_id']; // ID do usuário logado

// Verificar se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Coletar os dados do formulário
    $id_produto = $_POST['id_produto'];
    $quantidade = $_POST['quantidade'];

    // Consultar o produto no banco de dados
    $sql_produto = "SELECT * FROM produtos WHERE id = ?";
    $stmt_produto = $conn->prepare($sql_produto);
    $stmt_produto->bind_param("i", $id_produto);
    $stmt_produto->execute();
    $produto = $stmt_produto->get_result()->fetch_assoc();

    // Se o produto for encontrado, insere no carrinho
    if ($produto) {
        // Verifica se o produto já está no carrinho do usuário
        $sql_verifica = "SELECT * FROM carrinho WHERE id_produto = ? AND id_usuario = ?";
        $stmt_verifica = $conn->prepare($sql_verifica);
        $stmt_verifica->bind_param("ii", $id_produto, $usuario_id);
        $stmt_verifica->execute();
        $produto_no_carrinho = $stmt_verifica->get_result()->fetch_assoc();

        if ($produto_no_carrinho) {
            // Atualiza a quantidade se o produto já estiver no carrinho
            $nova_quantidade = $produto_no_carrinho['quantidade'] + $quantidade;
            $sql_atualiza = "UPDATE carrinho SET quantidade = ? WHERE id_produto = ? AND id_usuario = ?";
            $stmt_atualiza = $conn->prepare($sql_atualiza);
            $stmt_atualiza->bind_param("iii", $nova_quantidade, $id_produto, $usuario_id);
            $stmt_atualiza->execute();
        } else {
            // Inserir o produto no carrinho
            $sql_carrinho = "INSERT INTO carrinho (id_produto, quantidade, id_usuario) VALUES (?, ?, ?)";
            $stmt_carrinho = $conn->prepare($sql_carrinho);
            $stmt_carrinho->bind_param("iii", $id_produto, $quantidade, $usuario_id);
            $stmt_carrinho->execute();
        }

        // Não redireciona para a página carrinho.php, apenas exibe uma mensagem de sucesso
        echo "Produto adicionado ao carrinho com sucesso!";
    } else {
        echo "Produto não encontrado.";
    }
}
?>
