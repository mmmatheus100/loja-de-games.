/* Simulação de estado de autenticação (em um site real, essa informação viria do backend)

    let usuarioAutenticado = false;

    function adicionarAoCarrinho() {
        // Verifica se o usuário está autenticado
        if (!usuarioAutenticado) {
            // Redireciona para a página de login se não estiver autenticado
            alert("Você precisa fazer login para adicionar produtos ao carrinho.");
            window.location.href = "login.html";
            return;
        }

        // Caso esteja autenticado, prosseguir com a adição ao carrinho

        alert("Produto adicionado ao carrinho com sucesso!");

        // Aqui você pode adicionar a lógica para salvar o produto no carrinho
    }
*/
function filtrarProdutos() {
    const termoPesquisa = document.getElementById("pesquisaInput").value.toLowerCase().trim();
            const produtos = document.querySelectorAll(".apresentacao__form");
            let produtoEncontrado = false;

            produtos.forEach(produto => {
                const descricao = produto.querySelector("h2").textContent.toLowerCase();
                if (descricao.includes(termoPesquisa)) {
                    produto.style.display = "flex";
                    produtoEncontrado = true;
                } else {
                    produto.style.display = "none";
                }
            });

            document.getElementById("nenhumProduto").style.display = produtoEncontrado ? "none" : "block";
        }
    