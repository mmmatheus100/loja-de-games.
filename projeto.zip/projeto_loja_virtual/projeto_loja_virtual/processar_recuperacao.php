<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmação de Recuperação</title>
    <link rel="stylesheet" href="assets/styles/recuperacao.css">
</head>
<body>
    <div class="mensagem_confirmacao">
    <h1 class="mensagem_email">Verifique seu e-mail</h1>
    <div class="barra-horizontal"></div>
    <p class="mensagem_link">Enviamos um link de recuperação para o e-mail informado, caso ele esteja cadastrado em nosso sistema.</p>
    <a href="login.html">Voltar para o login</a>
    </div>
</body>
</html>