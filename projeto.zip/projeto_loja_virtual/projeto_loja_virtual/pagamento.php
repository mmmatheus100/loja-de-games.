<?php
session_start();
include 'conexao.php'; // Conecta ao banco de dados

// Verifica se o usuário está autenticado
if (!isset($_SESSION['usuario_id'])) {
    echo "Você precisa fazer login para realizar o pagamento.";
    exit;
}

$usuario_id = $_SESSION['usuario_id']; // ID do usuário logado

// Consulta para calcular o total do carrinho
$sql_total = "SELECT SUM(c.quantidade * p.preco) AS total
              FROM carrinho c
              JOIN produtos p ON c.id_produto = p.id
              WHERE c.id_usuario = ?";

// Preparar a consulta
if ($stmt = $conn->prepare($sql_total)) {
    // Vincular o parâmetro (ID do usuário)
    $stmt->bind_param("i", $usuario_id); // "i" indica que é um inteiro

    // Executar a consulta
    $stmt->execute();

    // Obter o resultado
    $result = $stmt->get_result();
    $total = 0;
    if ($row = $result->fetch_assoc()) {
        $total = $row['total'];
    }

    // Fechar o statement
    $stmt->close();
} else {
    echo "Erro ao calcular o total do carrinho: " . $conn->error;
}

// Fechar a conexão
$conn->close();

// Incluir o arquivo HTML para pagamento
include 'pagamento.html';
?>
