<?php
session_start();
include 'conexao.php'; // Conecta ao banco de dados

// Verifica se o usuário está autenticado
if (!isset($_SESSION['usuario_id'])) {
    echo "Você precisa fazer login para remover produtos do carrinho.";
    exit;
}

$usuario_id = $_SESSION['usuario_id']; // ID do usuário logado
$produto_id = $_GET['id_produto']; // ID do produto a ser removido, usando GET

// Verifica se o ID do produto foi passado e é válido
if (!isset($produto_id) || empty($produto_id)) {
    echo "ID do produto inválido.";
    exit;
}

// Prepara a consulta SQL para remover o produto
$sql = "DELETE FROM carrinho WHERE id_produto = ? AND id_usuario = ?";

if ($stmt = $conn->prepare($sql)) {
    // Vincula os parâmetros (ID do produto e ID do usuário)
    $stmt->bind_param("ii", $produto_id, $usuario_id);

    // Executa a consulta
    if ($stmt->execute()) {
        echo "Produto removido do carrinho com sucesso!";
    } else {
        echo "Erro ao remover o produto: " . $stmt->error;
    }

    // Fecha o statement
    $stmt->close();
} else {
    echo "Erro ao preparar a consulta: " . $conn->error;
}

// Redireciona para o carrinho atualizado
header("Location: carrinho.php");
exit();
?>
